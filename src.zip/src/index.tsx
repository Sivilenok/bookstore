import React from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter, Route, Routes } from 'react-router-dom';
import { MainPage } from './pages/main/main-page';
import { GlobalStyles } from './ui';

const root = createRoot(document.getElementById('root') as HTMLElement);
root.render(
  <React.StrictMode>
    <GlobalStyles />
    <HashRouter>
      <Routes>
        <Route path='/' element={<MainPage />} />
      </Routes>
    </HashRouter>
  </React.StrictMode>
);
