import { ReactComponent as LogoIcon} from "./icons/logo.svg";
import { ReactComponent as AvatarIcon} from "./icons/avatar.svg";
import { ReactComponent as CatIcon } from "./icons/cat.svg";

import bookImage from './image/book.png';

export { LogoIcon, AvatarIcon, CatIcon, bookImage };
