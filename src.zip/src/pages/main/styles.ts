import styled from "styled-components";
import { Media } from "../../ui";

const StyledMainPage = styled.div`
  display: grid;
  grid-template-columns: 1fr 3fr;
  gap: 6px;
  margin-bottom: 62px;
  ${Media.MD} {
    grid-template-columns: none;
  }
`;

export { StyledMainPage };
