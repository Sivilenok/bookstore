import { BookList, Header, Menu } from '../../components'
import { StyledMainPage } from './styles';
import data from '../../services/books.json';
import { useWindowSize } from '../../hooks';

export const MainPage = () => {
  const allBooks = Object.values(data).flatMap((books) => books);
  const { width = 0 } = useWindowSize();

  return (
    <StyledMainPage>
      {width > 768 && <Menu />}
      <Header />
      <BookList books={allBooks} $view={false} />
    </StyledMainPage>
  )
}

