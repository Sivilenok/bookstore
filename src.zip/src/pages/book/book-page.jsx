export const BookPage = () => (
    <section className='book-page'>
    </section>
);
