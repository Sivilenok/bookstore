import { Outlet } from "react-router-dom";
import { Header } from "../components";
import Footer from "../components/footer/footer";
import { Container } from "../ui";


export const Layout = () => (
    <Container>
      <Header />
      <Outlet />
      <Footer />
    </Container>
  );