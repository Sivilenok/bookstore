import { StyledBreadcrumbs } from "./styles";

export const Breadcrumbs = () => (
    <StyledBreadcrumbs>
      Бизнес книги / Грокаем алгоритмы.Иллюстрированное пособие для программистов и любопытствующих
    </StyledBreadcrumbs>
  );