import styled from "styled-components";

const StyledBreadcrumbs = styled.div``;

export { StyledBreadcrumbs };
