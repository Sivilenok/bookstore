import { ROUTE } from "../../router";
import { Border, LinksWrapper, MenuItem, MenuTitle, MenuWrapper } from "./styles";
import { Link } from 'react-router-dom';


export const Menu = () => (
   <MenuWrapper>
     <ul>
        <MenuTitle>Витрина книг</MenuTitle>
        <Border />
        <MenuItem>Все книги</MenuItem>
        <MenuItem>Бизнес-книги</MenuItem>
        <MenuItem>Детективы</MenuItem>
        <MenuItem>Детские книги</MenuItem>
        <MenuItem>Зарубежная литература</MenuItem>
        <MenuItem>История</MenuItem>
        <MenuItem>Классическая литература</MenuItem>
        <MenuItem>Книги по психологии</MenuItem>
        <MenuItem>Компьютерная литература</MenuItem>
        <MenuItem>Культура и искусство</MenuItem>
        <MenuItem>Наука и образование</MenuItem>
        <MenuItem>Публицистическая литература</MenuItem>
        <MenuItem>Справочники</MenuItem>
        <MenuItem>Фантастика</MenuItem>
        <MenuItem>Юмористическая литература</MenuItem>
     </ul>
     <LinksWrapper>
      <Link to={ROUTE.TERMS}>Правила пользования</Link>
      <Link to={ROUTE.OFFER}>Договор оферты</Link>
    </LinksWrapper>
    
    </MenuWrapper>
);