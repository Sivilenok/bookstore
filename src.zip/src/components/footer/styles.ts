import styled from 'styled-components';

const Footer = styled.div`
`;
