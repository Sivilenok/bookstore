import { createBrowserRouter, createRoutesFromElements, Route } from "react-router-dom";
import { BookPage } from "../pages/book/book-page";
import { Layout } from "../components/layout/layout";
import { MainPage } from "../pages/main/main-page";
import { ROUTE } from "./routes";


export const router = createBrowserRouter(
    createRoutesFromElements(
      <Route element={<Layout />} path={ROUTE.ROOT}>
        <Route element={<MainPage />} path={ROUTE.CATEGORY} />
        <Route element={<BookPage />} path={ROUTE.CATEGORY} />
        <Route element={<BookPage />} path={ROUTE.OFFER} />
        <Route element={<BookPage />} path={ROUTE.DETAILS} />
        <Route element={<BookPage />} path={ROUTE.TERMS} />
      </Route>
    )
);