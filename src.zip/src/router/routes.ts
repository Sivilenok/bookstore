export enum ROUTE {
  ROOT = '/',
  CATEGORY = 'books/:category',
  DETAILS = 'books/:category/:id',
  TERMS = 'terms',
  OFFER = 'offer',
}